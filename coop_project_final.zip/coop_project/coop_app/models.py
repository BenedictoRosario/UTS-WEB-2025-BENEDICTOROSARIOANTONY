from django.db import models
from django.contrib.auth.models import User

GENDER_CHOICES = [('M','Laki-laki'),('F','Perempuan')]

class StudentProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    nama = models.CharField(max_length=100)
    nim = models.CharField(max_length=20, unique=True)
    prodi = models.CharField(max_length=100)
    angkatan = models.CharField(max_length=10)
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    outlook_email = models.EmailField(unique=True)
    wa = models.CharField(max_length=30)
    bukti_konsultasi = models.FileField(upload_to='bukti/', null=True, blank=True)
    bukti_sptjm = models.FileField(upload_to='bukti/', null=True, blank=True)
    cv = models.FileField(upload_to='dokumen/', null=True, blank=True)
    portofolio = models.FileField(upload_to='dokumen/', null=True, blank=True)

    def __str__(self):
        return f'{self.nama} ({self.nim})'

class JobPosting(models.Model):
    title = models.CharField(max_length=150)
    company = models.CharField(max_length=150)
    description = models.TextField()
    deadline = models.DateField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f'{self.title} - {self.company}'

class JobApplication(models.Model):
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    posting = models.ForeignKey(JobPosting, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=30, default='applied')  # applied/accepted/rejected

    class Meta:
        unique_together = ('student', 'posting')

class InternshipConfirmation(models.Model):
    student = models.OneToOneField(User, on_delete=models.CASCADE)
    periode = models.CharField(max_length=100)
    posisi = models.CharField(max_length=100)
    nama_perusahaan = models.CharField(max_length=150)
    alamat_perusahaan = models.CharField(max_length=200)
    bidang_usaha = models.CharField(max_length=150)
    nama_supervisor = models.CharField(max_length=100)
    email_supervisor = models.EmailField()
    wa_supervisor = models.CharField(max_length=30, blank=True)
    surat_penerimaan = models.FileField(upload_to='surat/')
    approved_admin = models.BooleanField(default=False)
    batas_masuk_tempat = models.DateField(null=True, blank=True)  # untuk reminder mingguan

    def __str__(self):
        return f'Konfirmasi {self.student.username} - {self.nama_perusahaan}'

EVAL_TYPE = [('UTS','UTS'),('UAS','UAS')]

class SupervisorEvaluation(models.Model):
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    eval_type = models.CharField(max_length=3, choices=EVAL_TYPE)
    sent = models.BooleanField(default=False)         # admin mengirim evaluasi
    completed = models.BooleanField(default=False)    # supervisor sudah isi?
    uploaded_file = models.FileField(upload_to='evaluasi/', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('student','eval_type')

class MonthlyProgressReport(models.Model):
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    month = models.DateField(help_text='Gunakan tanggal pertama di bulan tsb')
    profil_perusahaan = models.TextField()
    jobdesk = models.TextField()
    suasana = models.TextField()
    manfaat_kuliah = models.TextField()
    kekosongan_pembelajaran = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

class Certificate(models.Model):
    student = models.OneToOneField(User, on_delete=models.CASCADE)
    perusahaan = models.CharField(max_length=150)
    periode = models.CharField(max_length=100)
    prodi = models.CharField(max_length=100)
    nilai_konversi = models.CharField(max_length=10, default='A')
    issued_at = models.DateField(auto_now_add=True)

    def __str__(self):
        return f'Sertifikat {self.student.username}'
