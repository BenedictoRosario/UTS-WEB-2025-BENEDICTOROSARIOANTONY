from django import forms
from django.contrib.auth.models import User
from .models import StudentProfile, InternshipConfirmation, MonthlyProgressReport

class RegisterForm(forms.Form):
    # username = email outlook (biar simpel)
    nama = forms.CharField(max_length=100)
    password = forms.CharField(widget=forms.PasswordInput)
    nim = forms.CharField(max_length=20)
    prodi = forms.CharField(max_length=100)
    angkatan = forms.CharField(max_length=10)
    gender = forms.ChoiceField(choices=[('M','Laki-laki'),('F','Perempuan')])
    outlook_email = forms.EmailField(label="Email Outlook (sebagai username)")
    wa = forms.CharField(label='Kontak WA', max_length=30)
    bukti_konsultasi = forms.FileField(required=False)
    bukti_sptjm = forms.FileField(required=False)

    cv = forms.FileField(required=False)
    portofolio = forms.FileField(required=False)

    def clean_outlook_email(self):
        email = self.cleaned_data['outlook_email'].lower()
        if User.objects.filter(username=email).exists():
            raise forms.ValidationError("Email ini sudah terdaftar")
        return email

class InternshipConfirmationForm(forms.ModelForm):
    class Meta:
        model = InternshipConfirmation
        exclude = ('student','approved_admin')

class MonthlyProgressForm(forms.ModelForm):
    class Meta:
        model = MonthlyProgressReport
        fields = ['month','profil_perusahaan','jobdesk','suasana','manfaat_kuliah','kekosongan_pembelajaran']
