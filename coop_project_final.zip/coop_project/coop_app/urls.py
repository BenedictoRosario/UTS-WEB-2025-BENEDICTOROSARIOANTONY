from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register, name='register'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('jobs/', views.job_list, name='job_list'),
    path('jobs/<int:pk>/', views.job_detail, name='job_detail'),
    path('confirm/', views.confirm_internship, name='confirm_internship'),
    path('progress/new/', views.progress_create, name='progress_create'),
    path('certificate/', views.view_my_certificate, name='view_my_certificate'),

    # admin/unit coop helper pages
    path('admin-tools/status/', views.supervisor_status, name='supervisor_status'),
    path('admin-tools/approve/<int:uid>/', views.approve_konfirmasi, name='approve_konfirmasi'),
    path('admin-tools/send/<int:uid>/<str:etype>/', views.toggle_send_eval, name='toggle_send_eval'),
    path('admin-tools/complete/<int:uid>/<str:etype>/', views.toggle_complete_eval, name='toggle_complete_eval'),
    path('admin-tools/certificate/<int:uid>/', views.generate_certificate, name='generate_certificate'),
]
