from datetime import date, timedelta
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from .forms import RegisterForm, InternshipConfirmationForm, MonthlyProgressForm
from .models import (StudentProfile, JobPosting, JobApplication, InternshipConfirmation,
                     SupervisorEvaluation, MonthlyProgressReport, Certificate)

def home(request):
    return render(request, 'coop_app/home.html')

def is_admin(user):
    return user.is_superuser

def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST, request.FILES)
        if form.is_valid():
            email = form.cleaned_data['outlook_email'].lower()
            user = User.objects.create_user(username=email, email=email,
                                            password=form.cleaned_data['password'])
            profile = StudentProfile.objects.create(
                user=user,
                nama=form.cleaned_data['nama'],
                nim=form.cleaned_data['nim'],
                prodi=form.cleaned_data['prodi'],
                angkatan=form.cleaned_data['angkatan'],
                gender=form.cleaned_data['gender'],
                outlook_email=email,
                wa=form.cleaned_data['wa'],
                bukti_konsultasi=form.cleaned_data.get('bukti_konsultasi'),
                bukti_sptjm=form.cleaned_data.get('bukti_sptjm'),
                cv=form.cleaned_data.get('cv'),
                portofolio=form.cleaned_data.get('portofolio'),
            )
            # login langsung
            user = authenticate(request, username=email, password=form.cleaned_data['password'])
            login(request, user)
            messages.success(request, 'Registrasi berhasil. Lengkapi data anda di Dashboard.')
            return redirect('dashboard')
    else:
        form = RegisterForm()
    return render(request, 'coop_app/register.html', {'form': form})

@login_required
def dashboard(request):
    profile = StudentProfile.objects.filter(user=request.user).first()
    konfirmasi = InternshipConfirmation.objects.filter(student=request.user).first()
    apps = JobApplication.objects.filter(student=request.user).select_related('posting')
    uts = SupervisorEvaluation.objects.filter(student=request.user, eval_type='UTS').first()
    uas = SupervisorEvaluation.objects.filter(student=request.user, eval_type='UAS').first()
    progress = MonthlyProgressReport.objects.filter(student=request.user).order_by('-month')
    certificate = Certificate.objects.filter(student=request.user).first()
    return render(request, 'coop_app/dashboard.html', {
        'profile': profile, 'konfirmasi': konfirmasi, 'apps': apps,
        'uts': uts, 'uas': uas, 'progress': progress, 'certificate': certificate
    })

@login_required
def job_list(request):
    posts = JobPosting.objects.filter(is_active=True).order_by('-id')
    return render(request, 'coop_app/job_list.html', {'posts': posts})

@login_required
def job_detail(request, pk):
    post = get_object_or_404(JobPosting, pk=pk, is_active=True)
    already = JobApplication.objects.filter(student=request.user, posting=post).exists()
    if request.method == 'POST' and not already:
        JobApplication.objects.create(student=request.user, posting=post)
        messages.success(request, 'Berhasil mendaftar lowongan.')
        return redirect('job_detail', pk=pk)
    return render(request, 'coop_app/job_detail.html', {'post': post, 'already': already})

@login_required
def confirm_internship(request):
    instance = InternshipConfirmation.objects.filter(student=request.user).first()
    if request.method == 'POST':
        form = InternshipConfirmationForm(request.POST, request.FILES, instance=instance)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.student = request.user
            obj.save()
            # buat placeholder evaluasi UTS/UAS kalau belum ada
            for t in ['UTS','UAS']:
                SupervisorEvaluation.objects.get_or_create(student=request.user, eval_type=t)
            messages.success(request, 'Konfirmasi magang tersimpan.')
            return redirect('dashboard')
    else:
        form = InternshipConfirmationForm(instance=instance)
    return render(request, 'coop_app/confirm_internship.html', {'form': form})

@login_required
def progress_create(request):
    if request.method == 'POST':
        form = MonthlyProgressForm(request.POST)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.student = request.user
            obj.save()
            messages.success(request, 'Laporan kemajuan bulanan tersimpan.')
            return redirect('dashboard')
    else:
        form = MonthlyProgressForm()
    return render(request, 'coop_app/progress_form.html', {'form': form})

def view_my_certificate(request):
    # hanya pemilik akun yang boleh melihat
    profile = StudentProfile.objects.filter(user=request.user).first()
    cert = Certificate.objects.filter(student=request.user).first()
    if not (profile and cert):
        messages.error(request, 'Sertifikat belum tersedia.')
        return redirect('dashboard')

    # ambil konfirmasi yang sudah di-approve untuk menampilkan data perusahaan/periode
    kon = InternshipConfirmation.objects.filter(student=request.user, approved_admin=True).first()
    if not kon:
        messages.error(request, 'Konfirmasi magang belum disetujui admin.')
        return redirect('dashboard')

    return render(request, 'coop_app/certificate.html', {
        'profile': profile,
        'kon': kon,
        'cert': cert
    })

# ==== ADMIN/UNIT COOP HELPER VIEWS (sederhana) ====

@user_passes_test(is_admin)
def supervisor_status(request):
    # lihat siapa yang sudah/belum isi evaluasi + siapa yg belum konfirmasi
    konfirmasi_sudah = InternshipConfirmation.objects.filter(approved_admin=True).select_related('student')
    konfirmasi_belum = InternshipConfirmation.objects.filter(approved_admin=False).select_related('student')
    belum_konfirmasi_user = User.objects.exclude(internshipconfirmation__isnull=False)

    # reminder mingguan: mahasiswa melewati batas_masuk_tempat dan belum punya konfirmasi approved
    today = date.today()
    butuh_reminder = InternshipConfirmation.objects.filter(
        Q(batas_masuk_tempat__isnull=False) & Q(batas_masuk_tempat__lt=today) & Q(approved_admin=False)
    )

    uts = SupervisorEvaluation.objects.filter(eval_type='UTS')
    uas = SupervisorEvaluation.objects.filter(eval_type='UAS')
    ctx = {
        'konfirmasi_sudah': konfirmasi_sudah,
        'konfirmasi_belum': konfirmasi_belum,
        'belum_konfirmasi_user': belum_konfirmasi_user,
        'butuh_reminder': butuh_reminder,
        'uts': uts, 'uas': uas,
    }
    return render(request, 'coop_app/supervisor_status.html', ctx)

@user_passes_test(is_admin)
def toggle_send_eval(request, uid, etype):
    ev = get_object_or_404(SupervisorEvaluation, student_id=uid, eval_type=etype)
    ev.sent = not ev.sent
    ev.save()
    messages.success(request, f'Status kirim evaluasi {etype} diubah.')
    return redirect('supervisor_status')

@user_passes_test(is_admin)
def toggle_complete_eval(request, uid, etype):
    ev = get_object_or_404(SupervisorEvaluation, student_id=uid, eval_type=etype)
    ev.completed = not ev.completed
    ev.save()
    messages.success(request, f'Status selesai evaluasi {etype} diubah.')
    return redirect('supervisor_status')

@user_passes_test(is_admin)
def approve_konfirmasi(request, uid):
    kon = get_object_or_404(InternshipConfirmation, student_id=uid)
    kon.approved_admin = True
    kon.save()
    messages.success(request, 'Konfirmasi magang disetujui.')
    return redirect('supervisor_status')

@user_passes_test(is_admin)
def generate_certificate(request, uid):
    # buat/overwrite data sertifikat sederhana (disimpan di DB; tampilkan HTML)
    prof = get_object_or_404(StudentProfile, user_id=uid)
    kon = get_object_or_404(InternshipConfirmation, student_id=uid, approved_admin=True)
    cert, _ = Certificate.objects.update_or_create(
        student_id=uid,
        defaults={'perusahaan': kon.nama_perusahaan, 'periode': kon.periode, 'prodi': prof.prodi}
    )
    return render(request, 'coop_app/certificate.html', {'profile': prof, 'kon': kon, 'cert': cert})
