from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):
    initial = True
    dependencies = [('auth','0012_alter_user_first_name_max_length')]
    operations = [
        migrations.CreateModel(
            name='StudentProfile',
            fields=[
                ('id', models.AutoField(primary_key=True, serialize=False)),
                ('nama', models.CharField(max_length=100)),
                ('nim', models.CharField(max_length=20, unique=True)),
                ('prodi', models.CharField(max_length=100)),
                ('angkatan', models.CharField(max_length=10)),
                ('gender', models.CharField(choices=[('M','Laki-laki'),('F','Perempuan')], max_length=1)),
                ('outlook_email', models.EmailField(max_length=254, unique=True)),
                ('wa', models.CharField(max_length=30)),
                ('bukti_konsultasi', models.FileField(blank=True, null=True, upload_to='bukti/')),
                ('bukti_sptjm', models.FileField(blank=True, null=True, upload_to='bukti/')),
                ('cv', models.FileField(blank=True, null=True, upload_to='dokumen/')),
                ('portofolio', models.FileField(blank=True, null=True, upload_to='dokumen/')),
                ('user', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, to='auth.user')),
            ],
        ),
        migrations.CreateModel(
            name='JobPosting',
            fields=[
                ('id', models.AutoField(primary_key=True, serialize=False)),
                ('title', models.CharField(max_length=150)),
                ('company', models.CharField(max_length=150)),
                ('description', models.TextField()),
                ('deadline', models.DateField(blank=True, null=True)),
                ('is_active', models.BooleanField(default=True)),
            ],
        ),
        migrations.CreateModel(
            name='JobApplication',
            fields=[
                ('id', models.AutoField(primary_key=True, serialize=False)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('status', models.CharField(default='applied', max_length=30)),
                ('posting', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='coop_app.jobposting')),
                ('student', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='auth.user')),
            ],
            options={'unique_together': {('student','posting')}},
        ),
        migrations.CreateModel(
            name='InternshipConfirmation',
            fields=[
                ('id', models.AutoField(primary_key=True, serialize=False)),
                ('periode', models.CharField(max_length=100)),
                ('posisi', models.CharField(max_length=100)),
                ('nama_perusahaan', models.CharField(max_length=150)),
                ('alamat_perusahaan', models.CharField(max_length=200)),
                ('bidang_usaha', models.CharField(max_length=150)),
                ('nama_supervisor', models.CharField(max_length=100)),
                ('email_supervisor', models.EmailField(max_length=254)),
                ('wa_supervisor', models.CharField(blank=True, max_length=30)),
                ('surat_penerimaan', models.FileField(upload_to='surat/')),
                ('approved_admin', models.BooleanField(default=False)),
                ('batas_masuk_tempat', models.DateField(blank=True, null=True)),
                ('student', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, to='auth.user')),
            ],
        ),
        migrations.CreateModel(
            name='SupervisorEvaluation',
            fields=[
                ('id', models.AutoField(primary_key=True, serialize=False)),
                ('eval_type', models.CharField(choices=[('UTS','UTS'),('UAS','UAS')], max_length=3)),
                ('sent', models.BooleanField(default=False)),
                ('completed', models.BooleanField(default=False)),
                ('uploaded_file', models.FileField(blank=True, null=True, upload_to='evaluasi/')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('student', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='auth.user')),
            ],
            options={'unique_together': {('student','eval_type')}},
        ),
        migrations.CreateModel(
            name='MonthlyProgressReport',
            fields=[
                ('id', models.AutoField(primary_key=True, serialize=False)),
                ('month', models.DateField()),
                ('profil_perusahaan', models.TextField()),
                ('jobdesk', models.TextField()),
                ('suasana', models.TextField()),
                ('manfaat_kuliah', models.TextField()),
                ('kekosongan_pembelajaran', models.TextField()),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('student', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='auth.user')),
            ],
        ),
        migrations.CreateModel(
            name='Certificate',
            fields=[
                ('id', models.AutoField(primary_key=True, serialize=False)),
                ('perusahaan', models.CharField(max_length=150)),
                ('periode', models.CharField(max_length=100)),
                ('prodi', models.CharField(max_length=100)),
                ('nilai_konversi', models.CharField(default='A', max_length=10)),
                ('issued_at', models.DateField(auto_now_add=True)),
                ('student', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, to='auth.user')),
            ],
        ),
    ]
