from django.contrib import admin
from .models import (StudentProfile, JobPosting, JobApplication, InternshipConfirmation,
                     SupervisorEvaluation, MonthlyProgressReport, Certificate)

@admin.register(StudentProfile)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('nama','nim','prodi','angkatan','outlook_email')
    search_fields = ('nama','nim','outlook_email')

@admin.register(JobPosting)
class JobPostingAdmin(admin.ModelAdmin):
    list_display = ('title','company','is_active','deadline')
    list_filter = ('is_active',)

@admin.register(JobApplication)
class JobApplicationAdmin(admin.ModelAdmin):
    list_display = ('student','posting','status','created_at')
    list_filter = ('status',)

@admin.register(InternshipConfirmation)
class InternshipAdmin(admin.ModelAdmin):
    list_display = ('student','nama_perusahaan','periode','approved_admin','batas_masuk_tempat')
    list_filter = ('approved_admin',)

@admin.register(SupervisorEvaluation)
class SupervisorEvalAdmin(admin.ModelAdmin):
    list_display = ('student','eval_type','sent','completed','created_at')
    list_filter = ('eval_type','sent','completed')

@admin.register(MonthlyProgressReport)
class ProgressAdmin(admin.ModelAdmin):
    list_display = ('student','month','created_at')

@admin.register(Certificate)
class CertificateAdmin(admin.ModelAdmin):
    list_display = ('student','perusahaan','periode','nilai_konversi','issued_at')
