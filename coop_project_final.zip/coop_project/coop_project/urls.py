from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth.views import LogoutView
from coop_app.views import home

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/logout/', LogoutView.as_view(next_page='home'), name='logout'),
    path('accounts/', include('django.contrib.auth.urls')),  # login/logout
    path('', home, name='home'),
    path('coop/', include('coop_app.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
