# flights/forms.py
from django import forms

class SearchForm(forms.Form):
    origin = forms.CharField(
        max_length=3,
        label='Origin (IATA)',
        widget=forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'e.g. CGK'})
    )
    destination = forms.CharField(
        max_length=3,
        label='Destination (IATA)',
        widget=forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'e.g. DPS'})
    )
    departure_date = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-input'})
    )
    is_roundtrip = forms.BooleanField(required=False, label='Round trip?')
    return_date = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-input'})
    )

class BookingForm(forms.Form):
    offer_index = forms.CharField(widget=forms.HiddenInput())
    passenger_name = forms.CharField(
        max_length=100,
        widget=forms.TextInput(attrs={'class': 'form-input'})
    )
    passport_number = forms.CharField(
        max_length=50,
        widget=forms.TextInput(attrs={'class': 'form-input'})
    )
