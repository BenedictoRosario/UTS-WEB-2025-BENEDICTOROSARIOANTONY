from django.db import models

# Optional: simple Booking model (not used by views by default)
class Booking(models.Model):
    passenger_name = models.CharField(max_length=200)
    passport_number = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.passenger_name} ({self.passport_number})"
