# flights/views.py
import os
import requests
from datetime import date, datetime
from django.shortcuts import render, redirect
from .forms import SearchForm, BookingForm

# Environment / Amadeus settings
AMADEUS_CLIENT_ID = os.getenv('AMADEUS_CLIENT_ID')
AMADEUS_CLIENT_SECRET = os.getenv('AMADEUS_CLIENT_SECRET')
FORCE_MOCK = os.getenv('FORCE_MOCK', '') == '1'

AMADEUS_AUTH_URL = 'https://test.api.amadeus.com/v1/security/oauth2/token'
AMADEUS_FLIGHT_OFFERS_URL = 'https://test.api.amadeus.com/v2/shopping/flight-offers'

# --- Helpers ---------------------------------------------------------------
def get_amadeus_token():
    """Return Amadeus access token or raise RuntimeError if not configured/failed."""
    if not AMADEUS_CLIENT_ID or not AMADEUS_CLIENT_SECRET:
        raise RuntimeError('AMADEUS_CLIENT_ID / AMADEUS_CLIENT_SECRET not set in .env')
    data = {
        'grant_type': 'client_credentials',
        'client_id': AMADEUS_CLIENT_ID,
        'client_secret': AMADEUS_CLIENT_SECRET,
    }
    resp = requests.post(AMADEUS_AUTH_URL, data=data, timeout=10)
    resp.raise_for_status()
    return resp.json().get('access_token')

def _make_mock_offers(search):
    """Create mock offers for demo (used when no API key or on error)."""
    origin = search.get('origin', 'XXX')
    dest = search.get('destination', 'YYY')
    dep_date = search.get('departure_date', str(date.today()))
    if isinstance(dep_date, (date, datetime)):
        dep_date = dep_date.isoformat()
    return [
        {
            "id": "MOCK1",
            "price": {"total": "150.00", "currency": "USD"},
            "itineraries": [
                {"segments": [
                    {"departure": {"iataCode": origin, "at": dep_date},
                     "arrival": {"iataCode": dest},
                     "carrierCode": "GA"}
                ]}
            ]
        },
        {
            "id": "MOCK2",
            "price": {"total": "230.00", "currency": "USD"},
            "itineraries": [
                {"segments": [
                    {"departure": {"iataCode": origin, "at": dep_date},
                     "arrival": {"iataCode": dest},
                     "carrierCode": "QG"}
                ]}
            ]
        }
    ]

def _convert_dates(obj):
    """Recursively convert date/datetime in dict/list into ISO strings for JSON-serializable session storage."""
    if isinstance(obj, dict):
        return {k: _convert_dates(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_convert_dates(i) for i in obj]
    if isinstance(obj, (date, datetime)):
        return obj.isoformat()
    return obj

# --- Views -----------------------------------------------------------------
def search_flight(request):
    """Show search form and save JSON-serializable search_data to session."""
    if request.method == 'POST':
        form = SearchForm(request.POST)
        if form.is_valid():
            cleaned = form.cleaned_data.copy()
            cleaned = _convert_dates(cleaned)  # convert any dates to strings
            request.session['search_data'] = cleaned
            request.session.modified = True
            # clear old offers/booking to avoid mixing incompatible objects
            request.session.pop('offers', None)
            request.session.pop('last_booking', None)
            return redirect('flights:results')
    else:
        form = SearchForm()
    return render(request, 'flights/search.html', {'form': form})

def flight_results(request):
    """Perform flight search (Amadeus if configured) or fallback to mock; always returns HttpResponse."""
    search = request.session.get('search_data')
    if not search:
        return redirect('flights:search')

    # Ensure departure_date is string
    dep_date_val = search.get('departure_date')
    if isinstance(dep_date_val, (date, datetime)):
        dep_date = dep_date_val.isoformat()
    else:
        dep_date = str(dep_date_val)

    origin = search.get('origin')
    dest = search.get('destination')

    offers = []
    error = None

    try:
        if FORCE_MOCK or not (AMADEUS_CLIENT_ID and AMADEUS_CLIENT_SECRET):
            offers = _make_mock_offers(search)
        else:
            token = get_amadeus_token()
            headers = {'Authorization': f'Bearer {token}'}
            params = {
                'originLocationCode': origin,
                'destinationLocationCode': dest,
                'departureDate': dep_date,
                'adults': 1,
                'max': 10,
            }
            resp = requests.get(AMADEUS_FLIGHT_OFFERS_URL, headers=headers, params=params, timeout=10)
            if resp.status_code == 200:
                offers = resp.json().get('data', [])
            else:
                error = f"Amadeus API error: {resp.status_code}"
                offers = _make_mock_offers(search)
    except Exception as e:
        error = f"Error while searching flights: {str(e)}"
        offers = _make_mock_offers(search)

    # Convert any dates inside offers (to be safe) and save to session
    safe_offers = _convert_dates(offers)
    request.session['offers'] = safe_offers
    request.session.modified = True

    return render(request, 'flights/results.html', {
        'offers': safe_offers,
        'search': search,
        'error': error
    })

def flight_booking(request):
    """Simulated booking page (select an offer, fill passenger details)."""
    offers = request.session.get('offers', [])
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            try:
                idx = int(form.cleaned_data.get('offer_index', 0))
            except Exception:
                idx = 0
            booking = {
                'offer': offers[idx] if (isinstance(offers, list) and idx < len(offers)) else None,
                'name': form.cleaned_data.get('passenger_name'),
                'passport': form.cleaned_data.get('passport_number'),
            }
            request.session['last_booking'] = booking
            request.session.modified = True
            return render(request, 'flights/booking.html', {'booked': booking})
    else:
        initial = {'offer_index': 0}
        oi = request.GET.get('offer_index')
        if oi is not None:
            initial['offer_index'] = oi
        form = BookingForm(initial=initial)
    return render(request, 'flights/booking.html', {'form': form, 'offers': offers})
