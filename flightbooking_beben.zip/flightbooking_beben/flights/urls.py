from django.urls import path
from . import views

app_name = 'flights'

urlpatterns = [
    path('', views.search_flight, name='search'),
    path('results/', views.flight_results, name='results'),
    path('booking/', views.flight_booking, name='booking'),
]
