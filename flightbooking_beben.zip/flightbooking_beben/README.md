# FlightBooking - Mini Django App (Template)
This is a minimal Django project template for a flight booking mini-app used for coursework.
Follow the instructions below to run locally.

## Quick start (Windows)
1. Create virtual env:
   ```
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   ```
2. Create a `.env` file at project root (copy from `.env.example`) and fill values.
3. Run migrations and start server:
   ```
   python manage.py migrate
   python manage.py runserver
   ```
4. Open http://127.0.0.1:8000/

## Notes
- This template uses the Amadeus test API endpoints optionally. Set `AMADEUS_CLIENT_ID` and `AMADEUS_CLIENT_SECRET` in `.env` if you want to test API calls.
- This is a minimal educational template; security settings (DEBUG, SECRET_KEY) are simplified for local dev only.
